package com.example.asd;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomerAdapter extends ArrayAdapter<CostumerModel> {

    public CustomerAdapter(Context context, int resource, ArrayList<CostumerModel> objects)
    {
        super(context,resource,objects);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        CostumerModel costumerModel = getItem(position);
        if(convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item,parent,false);
        }
            TextView tv1 = (TextView) convertView.findViewById(R.id.text_view1);
        TextView tv2 = (TextView) convertView.findViewById(R.id.text_view2);
        TextView tv3 = (TextView) convertView.findViewById(R.id.text_view3);
        CheckBox cb = (CheckBox) convertView.findViewById(R.id.checkBox1);


        tv1.setText(costumerModel.getName());
        tv2.setText(costumerModel.getNrTel());
        tv3.setText(costumerModel.getPublicatie());
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    getItem(position).setSelected(true);
                }

            }
        });

        return convertView;
    }

    @Nullable
    @Override
    public CostumerModel getItem(int position) {
        return super.getItem(position);
    }

}
