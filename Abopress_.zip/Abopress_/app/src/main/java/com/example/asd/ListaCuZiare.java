package com.example.asd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.example.asd.R.layout.activity_lista_cu_ziare;
import static com.example.asd.R.menu.menu1;
import static java.lang.Thread.sleep;

public class ListaCuZiare extends AppCompatActivity {
    public static ArrayList<CostumerModel> costumerModellist = new ArrayList<CostumerModel>();
    EditText PopUpPhone;
    EditText PopUpName;
    EditText PopUpPublicatie;
    CostumerModel NewCostumerModel;
    CostumerModel ActualCostumerModel;
    public static boolean isActionMode = false;
    ArrayAdapter<CostumerModel> adapter;
    ListView lista;
    ArrayList<String> text;
    private final static int MY_PERMISSIONS_REQUEST_RECEIVE_SMS = 0;
    ArrayList<CostumerModel> list_items = new ArrayList<CostumerModel>();


    //text("Abonamentul dvs. expira luna aceasta, daca doriti sa-l inoiti trimite-ti sms cu cifra: 1-daca doriti sa nu-l mai reinoiti; 2-daca doriti sa renuntati la abonament;3-alte oferte de ziare,reviste,etc personalizate.");


    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        text = new ArrayList<String>();
        text.add("Abonamentul dvs. expira luna aceasta, trimite-ti sms cu cifra:");
        text.add("1-daca doriti sa-l prelungiti; 2-daca doriti sa renuntati la el");
        setContentView(activity_lista_cu_ziare);

        //       displayListView();
        //checkButtonClick();

        // lista = findViewById(R.id.lst1);

        setupData();
        setUpList();
        DataBaseHelper dataBaseHelper1 = new DataBaseHelper(ListaCuZiare.this);

        ActivityCompat.requestPermissions(ListaCuZiare.this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);
        //   registerForContextMenu();
    }

    public void setupData() {
        DataBaseHelper dataBaseHelper1 = new DataBaseHelper(ListaCuZiare.this);

        costumerModellist = (ArrayList<CostumerModel>) dataBaseHelper1.getEverybody();
    }

    public void setUpList() {
        DataBaseHelper dataBaseHelper1 = new DataBaseHelper(ListaCuZiare.this);

        lista = findViewById(R.id.lst1);
        CustomerAdapter adapter = new CustomerAdapter(getApplicationContext(), 0, costumerModellist);
        lista.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(menu1, menu);

        return true;
    }


    private void createNewContactDialog(CostumerModel ActualCostumerModel) {

        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup, null);
        PopUpName = contactPopupView.findViewById(R.id.PopUpName);
        PopUpPhone = contactPopupView.findViewById(R.id.PopUpPhone);
        PopUpPublicatie = contactPopupView.findViewById(R.id.PopUpPublicatie);

        Button EditButton = contactPopupView.findViewById(R.id.PopUpEdit);
        Button CancelButton = contactPopupView.findViewById(R.id.PopUpCancel);

        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        EditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NewCostumerModel = new CostumerModel(PopUpName.getText().toString(), PopUpPhone.getText().toString(), PopUpPublicatie.getText().toString());
                DataBaseHelper db = new DataBaseHelper(ListaCuZiare.this);
                db.Edit(ActualCostumerModel, NewCostumerModel);
                DataBaseHelper dataBaseHelper1 = new DataBaseHelper(ListaCuZiare.this);
                int i = adapter.getPosition(ActualCostumerModel);
                costumerModellist.set(i,NewCostumerModel);
                adapter = new CustomerAdapter(getApplicationContext(), 0, (ArrayList<CostumerModel>) db.getEverybody());
                adapter.notifyDataSetChanged();
                lista.setAdapter(adapter);

                dialog.dismiss();


            }
        });
        CancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getApplicationContext());
        adapter = new CustomerAdapter(getApplicationContext(), 0, costumerModellist);
        lista.setAdapter(adapter);
        switch (item.getItemId()) {

            case R.id.Up_delete:
                int n = lista.getCount();
                for (int i=n-1;i>=0;i--) {
                    n=n;
                    adapter.getItem(i).getSelected();


                    if (adapter.getItem(i).getSelected()) {
                        dataBaseHelper.deleteOne(adapter.getItem(i));
                        adapter.remove(adapter.getItem(i));
                        adapter.notifyDataSetChanged();

                    }
                }
                adapter = new CustomerAdapter(getApplicationContext(), 0, costumerModellist);
                lista.setAdapter(adapter);
                break;
            case R.id.Message:
                SmsManager mySmsManager = SmsManager.getDefault();
                n = lista.getCount();
                for (int i = n-1; i >= 0; i--) {
                    if (((CostumerModel) lista.getItemAtPosition(i)).getSelected()) {
                        mySmsManager.sendMultipartTextMessage(((CostumerModel) lista.getItemAtPosition(i)).getNrTel(), null, text, null, null);
                        //.sendTextMessage(((CostumerModel) lista.getItemAtPosition(i)).getNrTel(),null,"Abonamentul dvs. expira luna aceasta, daca doriti sa-l inoiti trimite-ti sms cu cifra: 1-daca doriti sa nu-l mai reinoiti; 2-daca doriti sa renuntati la abonament;3-alte oferte de ziare,reviste,etc personalizate.",null,null);

                    }
                }
                break;
            case R.id.Refresh:
                adapter = new CustomerAdapter(getApplicationContext(), 0, (ArrayList<CostumerModel>) dataBaseHelper.getEverybody());
                lista.setAdapter(adapter);
                break;

            case R.id.Editm:
                adapter = new CustomerAdapter(getApplicationContext(), 0, costumerModellist);
                lista.setAdapter(adapter);
                int contor = 0;
                CostumerModel costumerModel = new CostumerModel();
                for (int i = 0; i < lista.getCount(); i++) {
                    adapter.getItem(i).getSelected();
                    if (adapter.getItem(i).getSelected())
                    {
                        costumerModel = adapter.getItem(i);
                        contor++;
                        if(contor>1)
                        {
                            Toast.makeText( getApplicationContext(),"Nu poate fi edicat mai mult de o persoana concomitent" , Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }
                }
                for(int i=0;i<adapter.getCount();i++)
                {
                    adapter.getItem(i).setSelected(false);
                }


                if(contor == 1) {
                    createNewContactDialog(costumerModel);
                    contor=0;
                }
        }
        return super.onOptionsItemSelected(item);
    }
}









