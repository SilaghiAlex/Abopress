package com.example.asd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String CUSTOMER_TABLE = "CUSTOMER_TABLE";
    public static final String NUMARTEL = "NUMARTEL";
    public static final String CUSTOMER_NAME = "CUSTOMER_NAME";
    public static final String PUBLICATIE = "PUBLICATIE";

    public DataBaseHelper(@Nullable Context context) {
        super(context, "customer.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CreateTableStatement = "CREATE TABLE " + CUSTOMER_TABLE + " (" + NUMARTEL + " TEXT primary key, " + CUSTOMER_NAME + " TEXT, " + PUBLICATIE + " TEXT )";
        db.execSQL(CreateTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean addOne (CostumerModel costumerModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(CUSTOMER_NAME,costumerModel.getName());
        cv.put(NUMARTEL,costumerModel.getNrTel());
        cv.put(PUBLICATIE, costumerModel.getPublicatie());

        long insert = db.insert(CUSTOMER_TABLE, null, cv);
        return insert != -1;
    }

    public boolean deleteOne(CostumerModel costumerModel ){

        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = String.format("DELETE FROM %s WHERE NUMARTEL='%s'", CUSTOMER_TABLE,costumerModel.getNrTel());
        Cursor cursor = db.rawQuery(queryString,null);
        return cursor.moveToFirst();
    }

    public List<CostumerModel> getEverybody(){

        List<CostumerModel> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + CUSTOMER_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst()) {
            do{
                String cursorPublicatie = cursor.getString(2);
                String cursorName = cursor.getString(1);
                String cursorTel = cursor.getString(0);

                CostumerModel costumerModel = new CostumerModel(cursorName,cursorTel,cursorPublicatie);
                returnList.add(costumerModel);

            }while(cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return returnList;
    }

    public void Edit(CostumerModel OldCostumerModel, CostumerModel NewCostumerModel ) {
        String queryString = String.format("UPDATE %s SET CUSTOMER_NAME='%s', NUMARTEL='%s', PUBLICATIE='%s' WHERE CUSTOMER_NAME='%s' AND NUMARTEL='%s' AND PUBLICATIE='%s' ", CUSTOMER_TABLE,NewCostumerModel.getName() ,NewCostumerModel.getNrTel(),NewCostumerModel.getPublicatie(),OldCostumerModel.getName(),OldCostumerModel.getNrTel(),OldCostumerModel.getPublicatie());
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(queryString);
    }
}

