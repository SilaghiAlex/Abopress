package com.example.asd;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.example.asd.ListaCuZiare.costumerModellist;

public class MyReceiver extends BroadcastReceiver {

    public static final  String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    public static final String TAG = "SmsBroadcastReceiver";
    String msg,phoneNo="";
    @Override
    public void onReceive(Context context, Intent intent) {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(context);
        Log.i(TAG,"Intent received"+intent.getAction());
        if(intent.getAction()==SMS_RECEIVED)
        {
            Bundle dataBundle = intent.getExtras();
            if(dataBundle!=null)
            {
                Object[] mypdu = (Object[])dataBundle.get("pdus");
                final SmsMessage[] message = new SmsMessage[mypdu.length];

                for(int i = 0;i< mypdu.length;i++)
                {
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                    {
                        String format = dataBundle.getString("format");
                        message[i] = SmsMessage.createFromPdu((byte[])mypdu[i],format);
                    }
                    else
                    {
                        message[i]= SmsMessage.createFromPdu((byte[])mypdu[i]);
                    }
                    msg = message[i].getMessageBody();
                    phoneNo=message[i].getOriginatingAddress();
                }
                Toast.makeText(context,"Message: "+msg + "\nNumber: "+phoneNo,Toast.LENGTH_LONG).show();
                if(msg.equalsIgnoreCase("2"))
                {
                    CostumerModel TempCostumerModel = new CostumerModel();
                    TempCostumerModel.setNrTel(phoneNo);
                    CustomerAdapter adapter = new CustomerAdapter(context.getApplicationContext(), 0, (ArrayList<CostumerModel>) dataBaseHelper.getEverybody());
                   for(int i=0;i<adapter.getCount();i++)
                   {
                       if(adapter.getItem(i).getNrTel().equalsIgnoreCase(TempCostumerModel.getNrTel()))
                       {
                           adapter.remove(adapter.getItem(i));
                       }
                   }
                  //  adapter.remove(TempCostumerModel);
                    adapter.notifyDataSetChanged();
                    for(int i=0;i<costumerModellist.size();i++)
                    {

                        if(costumerModellist.get(i).getNrTel().equalsIgnoreCase(TempCostumerModel.getNrTel()))
                            costumerModellist.remove(costumerModellist.get(i));
                    }
                    dataBaseHelper.deleteOne(TempCostumerModel);

                }


            }
        }
    }
}