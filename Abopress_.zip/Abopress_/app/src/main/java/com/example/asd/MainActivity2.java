package com.example.asd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    Button Btn,ViewAll;
    EditText NameC, TelC, PublicatieC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Btn = findViewById(R.id.BtnAdd);
        ViewAll = findViewById(R.id.BtnViewAll);
        NameC = findViewById(R.id.editTextTextPersonName);
        TelC = findViewById(R.id.editTextPhone);
        PublicatieC = findViewById(R.id.EditTextPublicatie);


        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity2.this);





        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CostumerModel costumerModel = new CostumerModel();
                try {
                    costumerModel = new CostumerModel(NameC.getText().toString(), TelC.getText().toString(),PublicatieC.getText().toString());
                    Toast.makeText(MainActivity2.this,"Client added",Toast.LENGTH_LONG).show();

                }
                catch (Exception e) {
                    Toast.makeText(MainActivity2.this,"Error client couldn't be added",Toast.LENGTH_LONG).show();
                    costumerModel = new CostumerModel("","","");
                }
                DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity2.this);
                boolean success = dataBaseHelper.addOne(costumerModel);
                Toast.makeText(MainActivity2.this, String.format("ADD successfully %s %s", success, costumerModel.getName()), Toast.LENGTH_LONG).show();

            }
        });

        ViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity2.this, ListaCuZiare.class);
                startActivity(i);
            }
        });


    }



}