package com.example.asd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    Button Btn,ViewAll;
    EditText NameC, TelC, PublicatieC;
    private final static int MY_PERMISSIONS_REQUEST_RECEIVE_SMS = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Btn = findViewById(R.id.BtnAdd);
        ViewAll = findViewById(R.id.BtnViewAll);
        NameC = findViewById(R.id.editTextTextPersonName);
        TelC = findViewById(R.id.editTextPhone);
        PublicatieC = findViewById(R.id.EditTextPublicatie);



        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity2.this);
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity2.this, Manifest.permission.RECEIVE_SMS)) {
            } else {
                ActivityCompat.requestPermissions(MainActivity2.this, new String[]{Manifest.permission.RECEIVE_SMS}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);
            }
        }




        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CostumerModel costumerModel = new CostumerModel();
                try {
                if(!(NameC.getText().toString().isEmpty() && TelC.getText().toString().isEmpty() && PublicatieC.getText().toString().isEmpty())) {
                    costumerModel = new CostumerModel(NameC.getText().toString(), TelC.getText().toString(), PublicatieC.getText().toString());
                    DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity2.this);
                    boolean success = dataBaseHelper.addOne(costumerModel);
                    if(success== true)
                    Toast.makeText(MainActivity2.this, String.format("adaugat cu succes ", costumerModel.getName()), Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(MainActivity2.this, String.format("Exista deja in baza de date", costumerModel.getName()), Toast.LENGTH_SHORT).show();


                }
                          else
                            Toast.makeText(MainActivity2.this, "Toate campurile trebuie completate", Toast.LENGTH_LONG).show();

                    } catch (Exception e) {
                        Toast.makeText(MainActivity2.this, "Error client couldn't be added", Toast.LENGTH_LONG).show();
                        costumerModel = new CostumerModel("", "", "");
                    }


            }
        });

        ViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity2.this, ListaCuZiare.class);
                startActivity(i);
            }
        });


    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_RECEIVE_SMS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "thank you for permitting !", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(this, "I need access !", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }



}