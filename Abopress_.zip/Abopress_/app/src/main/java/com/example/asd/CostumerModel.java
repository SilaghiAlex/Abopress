package com.example.asd;


import android.os.Parcel;
import android.os.Parcelable;

public class CostumerModel implements Parcelable {
    private String name;
    private String Publicatie;
    private String NrTel;
    boolean selected=false;
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    public CostumerModel(String name, String nrTel,String Publicatie) {
        this.name = name;
        NrTel = nrTel;
        this.Publicatie = Publicatie;
    }
    public CostumerModel() {
    }
    protected CostumerModel(Parcel in) {
        name = in.readString();
        NrTel = in.readString();
        Publicatie = in.readString();
    }
    public static final Creator<CostumerModel> CREATOR = new Creator<CostumerModel>() {
        @Override
        public CostumerModel createFromParcel(Parcel in) {
            return new CostumerModel(in);
        }

        @Override
        public CostumerModel[] newArray(int size) {
            return new CostumerModel[size];
        }
    };
    public String getName() {
        return name;
    }
    public String getNrTel() {
        return NrTel;
    }
    public String getPublicatie(){return Publicatie;}
    public void setName(String name) {
        this.name = name;
    }
    public void setNrTel(String nrTel) {
        NrTel = nrTel;
    }
    @Override
    public String toString() {
        return "CostumerModel{" +
                "name='" + name + '\'' +
                ", Publicatie='" + Publicatie + '\'' +
                ", NrTel='" + NrTel + '\'' +
                '}';
    }

    public void setPublicatie(String Publicatie){this.Publicatie = Publicatie;}
    @Override
    public int describeContents() {
        return 0;
    }
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(NrTel);
        dest.writeString(Publicatie);
    }
    public boolean getSelected() {
        return selected;
    }
}
